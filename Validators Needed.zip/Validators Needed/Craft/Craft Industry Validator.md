> As a developer i want to be able to validate that an industry sent into the experience API is valid

- Create a validator that check the string of the supplied city against the craft data in the database
- If invalid the return an error. 
- Do we need fuzzy search to return possible matches?